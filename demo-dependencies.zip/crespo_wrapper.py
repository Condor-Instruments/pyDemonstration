import sys
import inspect
import os

root = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
sys.path.insert(0, root + '/pycrespo')
from crespo import Crespo as cr

def crespo_wrapper(df):
    onwrist = np.where(df["state"].to_numpy() == 4, False, True)

    cresp = cr(df["activity"].to_numpy()[onwrist],
               df["datetime"].to_numpy()[onwrist])
    cresp.model()

    state = np.where(onwrist,0,4)
    state[onwrist] = 1-cresp.refined_output

    return state