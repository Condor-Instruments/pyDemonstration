# Gradient boosting offwrist detection model - 2022
# Julius Andretti

import sys
import inspect
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # FATAL
os.environ['OUTDATED_IGNORE'] = '1'

import plotly.graph_objs as go
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pingouin as pg
import xgboost as xgb

from scipy.stats import pointbiserialr as pbsr
from plotly.subplots import make_subplots
from datetime import datetime, time, date, timedelta
from sklearn.metrics import confusion_matrix, auc
from scipy.ndimage import binary_closing, binary_opening

import logging
logging.getLogger('tensorflow').setLevel(logging.FATAL)

import warnings
warnings.filterwarnings("ignore")

folder = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
root = folder[0:(len(folder)-len("pyoffwrist"))]

from functions import *

sys.path.insert(0, root+"/pycrespo")
from crespo_functions import *

sys.path.insert(0, root+"/pylogit")
from logreg import LogReg

sys.path.insert(0, root+"/pylogread")
from logread import LogRead as lr

sys.path.insert(0, root+"pysleepstats")
from summarySleepStats import SummarySleepStats as sss
from dailyStats import DailyStats as ds
from generate_sleep_period_list import generate_sleep_period_list as gspl
from groupByDay import groupByDay as gbd
from sleep_periods import SleepPeriod as slp

def roc_curve(answer,prob,over=True,threshs=100,):
    min_thresh = np.min(prob)
    max_thresh = np.max(prob)
    thresholds = np.linspace(min_thresh,max_thresh,threshs)

    fpr = []
    tpr = []
    for thresh in thresholds:
        if over:
            predicted = np.where(prob >= thresh,1,0)
        else:
            predicted = np.where(prob < thresh,1,0)

        ravel = confusion_matrix(answer,predicted).ravel()
        if len(ravel) < 4:
            if predicted[0] == 0:
                fpr.append(0.0)
                tpr.append(1.0)
            else:
                fpr.append(0.0)
                tpr.append(0.0)
        else:
            tn, fp, fn, tp = ravel  # Calculates statistical scores
            fpr.append(fp/(fp+tn))
            tpr.append(tp/(tp+fn))

    return fpr,tpr

# cutoff = 0.5
mwl = 11

print("reading test files")
test_files = sorted(os.listdir("test_data"))
print("done\n")

cutoff_range = [0.75]
sleep_weight = 100
show_fig = True
train = False

if train:
    print("processing train data")
    # train_data = pd.read_csv("train_data.csv", delimiter = ';')
    store = pd.HDFStore("train_data.h5")
    train_data = store['df']
    train_sleep = train_data.iloc[:,-2].to_numpy()
    store.close()
    print("done\n")


results = pd.DataFrame([])
# results = pd.read_csv('results.csv', delimiter = ';')

# ja rodei até o 7
# for max_depth in range(3,11,3):
for max_depth in [6]:
    # for n_estimators in range(20,150,20): 
    for n_estimators in [80]:
                #    XGBRFClassifier
        xg_reg = xgb.XGBClassifier(objective='binary:logistic',
                                   max_delta_step=1,
                                   min_child_weight=10,
                                   # colsample_bytree=0.3,
                                   # scale_pos_weight=12,
                                   grow_policy="lossguide",
                                   learning_rate=0.05,
                                   max_depth=max_depth, 
                                   alpha=10, 
                                   n_estimators=n_estimators,
                                   eval_metric="auc",
                                   )
        if train:
            print("fitting model")
            X,y = train_data.iloc[:,1:-2],train_data.iloc[:,-1]
            y = 1-y.to_numpy()
            xg_reg.fit(X,y,sample_weight=np.where(train_sleep==1,sleep_weight,1))
            xg_reg.save_model("model_full_n="+str(n_estimators)+"_d="+str(max_depth)+".json")
            print("done\n")

        else:
            print("loading model")
            xg_reg.load_model("model_full_n="+str(n_estimators)+"_d="+str(max_depth)+".json")
            print("done\n")

        test_data = pd.DataFrame([])
        test_pred = np.array([])

        for cutoff in cutoff_range:
            cutoffs = []
            ac = []
            ss = []
            sp = []
            pr = []
            f1 = []
            gm = []
            over = []
            over_sleep = []
            ond = []
            offd = []

            print("processing test")
            for file in test_files:
                # data = pd.read_csv("test_data/"+file, delimiter = ';')
                store = pd.HDFStore("test_data/"+file)
                data = store['df']
                store.close()

                test_data = pd.concat([test_data,data],axis=0,ignore_index=True)

                X, answer = data.iloc[:,1:-2],data.iloc[:,-1]

                act = data["activity"].to_numpy()
                sleep = data.iloc[:,-2].to_numpy()

                prob = xg_reg.predict_proba(X)
                prob = prob[:,0]

                test_pred = np.append(test_pred,prob)

                cutoffs.append(cutoff)
                cutoff_ = cutoff
                out = np.where(prob >= cutoff_,1,0)

                strel = np.ones(8)   # Morphological strutcturing element
                out_morph = binary_opening(binary_closing(out,strel),strel).astype(int)

                n = len(out_morph)

                edges = np.concatenate(([0],np.diff(out_morph)))
                edges_index = edges.nonzero()[0]
                transitions = [[k,edges[k]] for k in edges_index]

                if len(transitions) > 0:
                    if transitions[0][1] > 0:
                        transitions.insert(0,[0,-1])

                    if transitions[-1][1] < 0:
                        transitions.append([n,1])

                offs = [[],[]]
                for transition in transitions:
                    if transition[1] < 0:
                        offs[0].append(transition[0])

                    elif transition[1] > 0:
                        offs[1].append(transition[0])

                offs = np.transpose(offs)
                print(file)
                # print(offs) 

                fullzp = below_prop(act,0)
                thresh = np.percentile(act,round(100*(fullzp+(1-fullzp)*0.33)))
                # print(thresh)

                num_offs = len(offs)
                remove = []
                for j in range(num_offs):
                    begin = offs[j,0]
                    end = offs[j,1]
                    zp = below_prop(act[begin:end],0)

                    if zp < 0.75:
                        remove.append(j)
                offs = np.delete(offs,remove,axis=0)

                out_filt = np.ones(n)
                for off in offs:
                    out_filt[off[0]:off[1]] = 0

                wl = 180
                num_offs = len(offs)
                remove = []
                for j in range(num_offs):
                    begin = offs[j,0]
                    end = offs[j,1]

                    length = end - begin

                    if j == 0:
                        end_below_prop = below_prop(act[end:end+wl],thresh)
                        end_on_prop = 1-below_prop(out_filt[end:end+wl],0)

                        if begin-wl >= 0:
                            begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                            begin_on_prop = 1-below_prop(out_filt[begin-wl:begin],0)
                        else:
                            begin_below_prop = below_prop(act[0:begin],thresh)
                            begin_on_prop = 1-below_prop(out_filt[0:begin],0)                            
                        

                    elif j == num_offs-1:
                        begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                        begin_on_prop = 1-below_prop(out_filt[begin-wl:begin],0)

                        if end+wl <= n:
                            end_below_prop = below_prop(act[end:end+wl],thresh)
                            end_below_prop = 1-below_prop(out_filt[end:end+wl],0)
                        else:
                            end_below_prop = below_prop(act[end:n],thresh)
                            end_on_prop = 1-below_prop(out_filt[end:n],0)

                    else:
                        begin_below_prop = below_prop(act[begin-wl:begin],thresh)
                        end_below_prop = below_prop(act[end:end+wl],thresh)

                        begin_on_prop = 1-below_prop(out_filt[begin-wl:begin],0)
                        end_on_prop = 1-below_prop(out_filt[end:end+wl],0)


                    if (begin_below_prop > 0.6) or (end_below_prop > 0.6):
                        if length <= 60:
                            if (begin_on_prop > 0.8) and (end_on_prop > 0.8):
                                remove.append(j)

                offs = np.delete(offs,remove,axis=0)
                # print(offs)
                # print("")

                out_filt = np.ones(n)
                for off in offs:
                    out_filt[off[0]:off[1]] = 0

                # print(data)

                # stamps = pd.to_datetime(data['dt'])
                # stamps = np.array([to_datetime(date) for date in stamps])
                # print(stamps)
                int_temp = data["temp_activity"].to_numpy()
                ext_temp = data["ext_temp"].to_numpy()

                over_sleep_ = np.zeros(n)
                for i in range(n):
                    if (out_filt[i] == 0) and (answer[i] == 1) and (sleep[i] == 1):
                        over_sleep_[i] = 1

                if show_fig:
                    layout = go.Layout(title="algo_analysis "+file,xaxis=dict(title="Date time"), yaxis=dict(title="Inputs"), showlegend=False)
                    layout.update(yaxis2=dict(overlaying='y',side='right'), showlegend=True)
                    layout.update(yaxis3=dict(overlaying='y',side='right'))

                    fig = go.Figure(data=[
                        go.Scatter(#x=stamps.astype(str),
                            y=act, name='act'),
                        go.Scatter(#x=stamps.astype(str),
                            y=thresh*np.ones(n), name='thresh'),
                        go.Scatter(#x=stamps.astype(str),
                            y=int_temp,yaxis='y3',name='temp'),
                        go.Scatter(#x=stamps.astype(str),
                            y=ext_temp,yaxis='y3',name='ext_temp'),
                        go.Scatter(#x=stamps.astype(str),
                            y=answer.to_numpy(), yaxis='y2', name='off'),
                        go.Scatter(#x=stamps.astype(str),
                            y=sleep, yaxis='y2', name='sleep'),
                        go.Scatter(#x=stamps.astype(str),
                            y=prob, yaxis='y2',name='prob'),
                        go.Scatter(#x=stamps.astype(str),
                            y=out, yaxis='y2', name='out'),
                        go.Scatter(#x=stamps.astype(str),
                            y=out_morph, yaxis='y2', name='out_morph'),
                        go.Scatter(#x=stamps.astype(str),
                            y=out_filt, yaxis='y2', name='out_filt'),
                        go.Scatter(#x=stamps.astype(str),
                            y=over_sleep_, yaxis='y2', name='over_sleep'),
                    ], layout=layout)

                    fig.show()

                # input()
                out = out_filt
                acc,sss,spp,precision,on_detect,off_detect,over_found,over_found_sleep = scores(answer,out,states=sleep)
                detection_on,valid_on,event_count_on = on_detect
                detection_off,valid_off,event_count_off = off_detect

                if np.isnan(spp):
                    spp = 1.0

                ac.append(acc)
                ss.append(sss)    
                sp.append(spp)
                pr.append(precision)
                f1.append(2*precision*sss/(precision+sss))
                gm.append(np.sqrt(sss*spp))
                over.append(over_found)
                over_sleep.append(over_found_sleep)
                ond.append(detection_on)
                offd.append(detection_off)
            
            mean_ac = np.mean(ac)
            mean_ss = np.mean(ss)
            mean_sp = np.mean(sp)
            mean_gm = np.mean(gm)
            mean_f1 = np.mean(f1)
            mean_pr = np.mean(pr)
            mean_over = np.mean(over)
            mean_over_sleep = np.mean(over_sleep)
            mean_ond = np.nanmean(ond)
            mean_offd = np.nanmean(offd)
            mean_mean_gm = np.sqrt(mean_ss*mean_sp)
            mean_mean_f1 = 2*mean_pr*mean_ss/(mean_pr+mean_ss)

            pdf = pd.DataFrame([])
            pdf["ac"] = ac
            pdf["ss"] = ss
            pdf["sp"] = sp
            pdf["over"] = over
            pdf["over_sleep"] = over_sleep
            pdf["ond"] = ond
            pdf["offd"] = offd
            pdf["f1"] = f1
            pdf["gm"] = gm
            pdf["mean_ac"] = mean_ac
            pdf["mean_ss"] = mean_ss
            pdf["mean_sp"] = mean_sp
            pdf["mean_over"] = mean_over
            pdf["mean_over_sleep"] = mean_over_sleep
            pdf["mean_ond"] = mean_ond
            pdf["mean_offd"] = mean_offd
            pdf["mean_gm"] = mean_gm
            pdf["mean_f1"] = mean_f1
            pdf["mean_mean_gm"] = mean_mean_gm
            pdf["mean_mean_f1"] = mean_mean_f1
            
            y = test_data.iloc[:,-1]
            fpr_pred,tpr_pred = roc_curve(y,test_pred,100)
            pdf["auc_pred"] = auc(fpr_pred,tpr_pred)

            pdf.insert(0,"max_depth",max_depth)
            pdf.insert(0,"n_estimators",n_estimators)

            results = pd.concat([results,pdf],axis=0,ignore_index=True)

            print("\n\nmax_depth",max_depth)
            print("n_estimators",n_estimators)
            print("mean_ac", mean_ac)
            print("mean_ss", mean_ss)
            print("mean_sp", mean_sp)
            print("mean_gm", mean_gm)
            print("mean_f1", mean_f1)
            print("mean_over", mean_over)
            print("mean_over_sleep", mean_over_sleep)
            print("mean_ond", mean_ond)
            print("mean_offd", mean_offd)
            print("mean_mean_gm", mean_mean_gm)
            print("mean_mean_f1", mean_mean_f1)
            print("auc_pred:",pdf.at[0,"auc_pred"])

        plt.figure()
        plt.rcParams['figure.figsize'] = [20, 14]
        plt.plot(fpr_pred,tpr_pred,label='pred')
        plt.title("roc_n="+str(n_estimators)+"_d="+str(max_depth))
        plt.savefig("roc_n="+str(n_estimators)+"_d="+str(max_depth)+".png")
        plt.close()

        plt.figure()
        plt.rcParams['figure.figsize'] = [20, 14]
        xgb.plot_importance(xg_reg,max_num_features=20)
        plt.title("fimp_n="+str(n_estimators)+"_d="+str(max_depth))
        plt.savefig("fimp_n="+str(n_estimators)+"_d="+str(max_depth)+".png")
        plt.close()

# results.sort_values(by=["n_estimators", "max_depth"])
results.to_csv(path_or_buf="results.csv",sep=';',header=True,index=False, index_label=None)