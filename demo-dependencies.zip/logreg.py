# -*- coding: utf-8 -*-

# Logistic Regression model: algorithm - 17/12/2019
# Julius Andretti

import sys,inspect,os,time,joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn import preprocessing

def zero_prop(a):
    n = len(a)
    return  np.sum(np.where(a == 0,1,0))/n

class LogReg:
    def __init__(self,activity,cut=0.02496,max_window_length=30,in_bed=None,shift=0,verbose=False,column_prefix="",variables=["std","mean","median","max","zp","full_zp"]):
        self.initStart = time.time()
        self.cutoff = cut # Probability threshold

        # Data processing
        start = time.time()

        # New information will be calculated using the activity data
        if "std" in variables:
            stda = [[] for i in range(max_window_length-1)] # Standard deviation of the next epochs
            stdb = [[] for i in range(max_window_length-1)] # Stamdard deviation of past epochs
            stds = [[] for i in range(max_window_length-1)]
        if "mean" in variables:
            meana = [[] for i in range(max_window_length-1)] # Mean of the next epochs
            meanb = [[] for i in range(max_window_length-1)] # Mean of past epochs
            means = [[] for i in range(max_window_length-1)]
        if "median" in variables:
            mediana = [[] for i in range(max_window_length-1)] # Median of the next epochs
            medianb = [[] for i in range(max_window_length-1)] # Median of past epochs
            medians = [[] for i in range(max_window_length-1)]
        if "max" in variables:
            maxa = [[] for i in range(max_window_length-1)] # Maximum value among the next epochs
            maxb = [[] for i in range(max_window_length-1)] # Maximum value among past epochs
            maxs = [[] for i in range(max_window_length-1)]
        if "zp" in variables:
            zpa = [[] for i in range(max_window_length-1)]
            zpb = [[] for i in range(max_window_length-1)]
            zps = [[] for i in range(max_window_length-1)]

        n = len(activity) # Number of points
        # print(n)

        activity_max = np.max(activity)

        if in_bed is None:
            for x in range(max_window_length):
                activity = np.insert(activity,0,activity_max) # 1s inserted at the beggining
                activity = np.append(activity,activity_max)   # 1s inserted at the end

            loop_start = max_window_length
            loop_end = n+max_window_length

            self.raw_activity = activity[loop_start:loop_end].copy()
            # activity = np.array(activity)/max(activity)
            self.normalized_activity = activity[loop_start:loop_end].copy()

            off,on = 0,n
            self.lights_off = off
            self.lights_on = on

        else:
            self.in_bed = in_bed
            edges = np.concatenate(([0],np.diff(in_bed)))
            edges_idx = edges.nonzero()[0]

            if len(edges_idx) == 2:
                off,on = edges_idx
            elif len(edges_idx) == 1:
                if n-edges_idx[0] > edges_idx[0]:
                    off,on = edges_idx[0],n
                else:
                    off,on = 0,edges_idx[0]
            else:
                off,on = 0,n
            
            self.lights_off = off
            self.lights_on = on

            off += shift
            on += shift

            if off < max_window_length:
                for x in range(max_window_length-off):
                    activity = np.insert(activity,0,activity_max) # 1s inserted at the beggining
                loop_start = max_window_length

            else:
                loop_start = off

            if on == n-1:
                on = n            

            if on+max_window_length > n:
                for x in range(on+max_window_length-n):
                    activity = np.append(activity,activity_max)
                loop_end = len(activity)-max_window_length

            else:
                loop_end = on

            loop_end += loop_start - off
             
            if verbose:
                print("borders")
                print(n)
                print(edges_idx)
                print(off,on)
                print(loop_start,loop_end)
                print("")
            
            self.raw_activity = activity[loop_start:loop_end].copy()
            # activity = np.array(activity)/max(activity)
            self.normalized_activity = activity[loop_start:loop_end].copy()

        n = len(self.normalized_activity)
        # print(n)

        # Values will be calculated on these next loops:
        for x in range(max_window_length-1):
            for j in range(loop_start,loop_end):
                # if verbose:
                #     print("loops")
                #     print(j-x-2,j)
                #     print(j+1,j+3+x)
                #     print(j-x-2,j+3+x)
                #     print("")

                if "mean" in variables:
                    meanb[x].append( np.mean(activity[(j-x-2):(j)]) )
                    meana[x].append( np.mean(activity[(j+1):(j+3+x)]) )
                    means[x].append( np.mean(activity[(j-x-2):(j+3+x)]) )
                if "median" in variables:
                    medianb[x].append( np.median(activity[(j-x-2):(j)]) )
                    mediana[x].append( np.median(activity[(j+1):(j+3+x)]) )
                    medians[x].append( np.median(activity[(j-x-2):(j+3+x)]) )
                if "std" in variables:
                    stdb[x].append( np.std(activity[(j-x-2):(j)]) )
                    stda[x].append( np.std(activity[(j+1):(j+3+x)]) )
                    stds[x].append( np.std(activity[(j-x-2):(j+3+x)]) )
                if "max" in variables:
                    maxb[x].append( np.max(activity[(j-x-2):(j)]) )
                    maxa[x].append( np.max(activity[(j+1):(j+3+x)]) )
                    maxs[x].append( np.max(activity[(j-x-2):(j+3+x)]) )
                if "zp" in variables:
                    zpa[x].append( zero_prop(activity[(j+1):(j+3+x)]) )
                    zpb[x].append( zero_prop(activity[(j-x-2):(j)]) )
                    zps[x].append( zero_prop(activity[(j-x-2):(j+3+x)]) )

        end = time.time()
        self.timeCalc = (end-start)

        # Data calculated and read will be stored into a DataFrame
        start = time.time()
        names = ['activity',]

        if "full_zp" in variables:
            names.append("full_zp")

        for i in range(max_window_length-1):
            if "mean" in variables:
                names.append('meanb_w='+str(i+2))
                names.append('meana_w='+str(i+2))
                names.append('means_w='+str(2*i+1+2))
            if "median" in variables:
                names.append('medianb_w='+str(i+2))
                names.append('mediana_w='+str(i+2))
                names.append('medians_w='+str(2*i+1+2))
            if "std" in variables:
                names.append('stdb_w='+str(i+2))
                names.append('stda_w='+str(i+2))
                names.append('stds_w='+str(2*i+1+2))
            if "max" in variables:
                names.append('maxb_w='+str(i+2))
                names.append('maxa_w='+str(i+2))
                names.append('maxs_w='+str(2*i+1+2))
            if "zp" in variables:
                names.append('zpa_w='+str(i+2))
                names.append('zpb_w='+str(i+2))
                names.append('zps_w='+str(2*i+1+2))

        names = [column_prefix+name for name in names]
        
        data = pd.DataFrame(data=np.zeros((len(names),n)),index=names)

        data.loc[column_prefix+'activity',:] = self.raw_activity.copy()

        if "full_zp" in variables:
           data.loc[column_prefix+'full_zp',:] = zero_prop(self.raw_activity)

        for a in range(max_window_length-1):
            if "mean" in variables:
                data.loc[column_prefix+'meanb_w='+str(a+2),:] = meanb[a].copy()
                data.loc[column_prefix+'meana_w='+str(a+2),:] = meana[a].copy()
                data.loc[column_prefix+'means_w='+str(2*a+1+2),:] = means[a].copy()
            if "median" in variables:
                data.loc[column_prefix+'medianb_w='+str(a+2),:] = medianb[a].copy()
                data.loc[column_prefix+'mediana_w='+str(a+2),:] = mediana[a].copy()
                data.loc[column_prefix+'medians_w='+str(2*a+1+2),:] = medians[a].copy()
            if "std" in variables:
                data.loc[column_prefix+'stdb_w='+str(a+2),:] = stdb[a].copy()
                data.loc[column_prefix+'stda_w='+str(a+2),:] = stda[a].copy()
                data.loc[column_prefix+'stds_w='+str(2*a+1+2),:] = stds[a].copy()
            if "max" in variables:
                data.loc[column_prefix+'maxb_w='+str(a+2),:] = maxb[a].copy()
                data.loc[column_prefix+'maxa_w='+str(a+2),:] = maxa[a].copy()
                data.loc[column_prefix+'maxs_w='+str(2*a+1+2),:] = maxs[a].copy()
            if "zp" in variables:
                data.loc[column_prefix+'zpa_w='+str(a+2),:] = zpa[a].copy()
                data.loc[column_prefix+'zpb_w='+str(a+2),:] = zpb[a].copy()
                data.loc[column_prefix+'zps_w='+str(2*a+1+2),:] = zps[a].copy()

        end = time.time()
        self.timeDF = (end-start)

        self.max_window_length = max_window_length
        self.variableNames = names
        self.n = n
        self.data = data.T # Transposed DataFrame is stored for convenience
        self.initEnd = time.time()
        self.timeInit = self.initEnd - self.initStart

    def model(self,previous=[],newState=1):
        start = time.time()
        dirpath = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
        self.logRegModel = joblib.load(dirpath+'/logregmodel.sav') # Loads logistic regression model
        self.pcaModel = joblib.load(dirpath+'/pcamodel.sav') # Loas PCA decomposition model
        end = time.time()
        self.timeLoad = (end-start)
        
        start = time.time()
        self.scaled = preprocessing.scale(self.data) # Data needs to be properly scaled (mean=0,var=1) before being fed to the PCA decomposition
        self.transformed = self.pcaModel.transform(self.scaled) # PCA decomposition of data
        probability = np.transpose(np.array([self.logRegModel.predict_proba([self.transformed[i]]) for i in range(len(self.transformed))]))[0][0] # Probabilities obtained using logistic regression

        if len(previous)==0:
            previous=np.zeros(self.n)
            
        result = np.zeros(self.n)
        for i in range(self.n):
            if probability[i] <= self.cutoff:
                result[i] = 1

        states = previous.copy()
        for i in range(self.n):
            if result[i] == 1:
                states[i] = newState

        self.states = states
        self.proba = proba
        end = time.time()
        self.timeModel = (end-start)
        self.totTime = self.timeInit + self.timeModel

    def plotStates(self):
        plt.figure()
        plt.plot(self.states)
        plt.xlabel('Epochs')
        plt.ylabel('States')
        plt.show()

    def printTimes():
        print('Time spent loading models:',self.timeLoad)
        print('Time spent calculating:',self.timeCalc)
        print('Time spent creating dataframe:',self.timeDF)
        print('Time spent scaling, transforming and scoring:',self.timeModel)
        print('Total time:', self.totTime)


