    # -*- coding: utf-8 -*-

# Log reading class - 24/09/2019
# Julius Andretti

import numpy as np
from datetime import datetime, timedelta, timezone
from scipy.stats import mode
import pandas as pd
import matplotlib.pyplot as plt

class LogRead:
    def __init__(self,file,ignore_rows=0,encoding="latin-1",dayfirst=True):
        # file is a string containing the path to the log file
        # header indicates if the log file has a header

        if not isinstance(file, str):
            raise Exception("Log path must be a string!")


        log = open(file,encoding=encoding)
        header = log.readline()
        
        ignore_rows = 0
        if header == "+-------------+ Condor Instruments Report +-------------+\n": # If the log has a header, it means we can ignore its first lines
            line = log.readline()
            header += line
            ignore_rows=2           
            while (line[0:3] != "+--"):
                line = log.readline()
                header += line
                ignore_rows += 1

        log.close()

        self.encoding = encoding
        self.file_name = file
        self.header = header

        data = pd.read_csv(file,skiprows=ignore_rows,delimiter=';',encoding=encoding,parse_dates=False)
        # print(data)

        self.date_time = []
        self.ms = []
        self.event = []
        self.temperature= []
        self.ext_temperature = []
        self.orientation = []
        self.pim = []
        self.pim_n = []
        self.tat = []
        self.tat_n = []
        self.zcm = []
        self.zcm_n = []
        self.light = []
        self.amb_light = []
        self.red_light = []
        self.green_light = []
        self.blue_light = []
        self.ir_light = []
        self.uva_light = []
        self.uvb_light = []
        self.state = []

        if 'DATE/TIME' in data.columns:
            self.date_time = data['DATE/TIME'].to_numpy()
            self.timestamps = pd.to_datetime(data['DATE/TIME'],dayfirst=dayfirst).to_numpy()

        if 'MS' in data.columns:
            self.ms = data['MS'].to_numpy() 

        if 'EVENT' in data.columns:
            self.event = data['EVENT'].to_numpy()

        if 'TEMPERATURE' in data.columns:
            self.temperature = data['TEMPERATURE'].to_numpy()

        if 'EXT TEMPERATURE' in data.columns:
            self.ext_temperature = data['EXT TEMPERATURE'].to_numpy()

        if 'ORIENTATION' in data.columns:
            self.orientation = data['ORIENTATION'].to_numpy()

        if 'PIM' in data.columns:
            self.pim = data['PIM'].to_numpy()

        if 'PIMn' in data.columns:
            self.pim_n = data['PIMn'].to_numpy()

        if 'TAT' in data.columns:
            self.tat = data['TAT'].to_numpy()

        if 'TATn' in data.columns:
            self.tat_n = data['TATn'].to_numpy()

        if 'ZCM' in data.columns:
            self.zcm = data['ZCM'].to_numpy()

        if 'ZCMn' in data.columns:
            self.zcm_n = data['ZCMn'].to_numpy()

        if 'LIGHT' in data.columns:
            self.light = data['LIGHT'].to_numpy()

        if 'AMB LIGHT' in data.columns:
            self.amb_light = data['AMB LIGHT'].to_numpy()

        if 'RED LIGHT' in data.columns:
            self.red_light = data['RED LIGHT'].to_numpy()

        if 'GREEN LIGHT' in data.columns:
            self.green_light = data['GREEN LIGHT'].to_numpy()

        if 'BLUE LIGHT' in data.columns:
            self.blue_light = data['BLUE LIGHT'].to_numpy()

        if 'IR LIGHT' in data.columns:
            self.ir_light = data['IR LIGHT'].to_numpy()

        if 'UVA LIGHT' in data.columns:
            self.uva_light = data['UVA LIGHT'].to_numpy()

        if 'UVB LIGHT' in data.columns:
            self.uvb_light = data['UVB LIGHT'].to_numpy()

        if 'STATE' in data.columns:
            self.state = data['STATE'].to_numpy()

        self.data = data
        self.epochs = len(self.data)
        self.columns = self.data.columns
        self.duration = mode([pd.Timedelta(self.timestamps[i]-self.timestamps[i-1])/np.timedelta64(1,'s') for i in range(1,self.epochs)]).mode[0]
        
    def plotter(self):
        for i in range(len(self.columns)):
            print(str(i+1)+'. '+self.columns[i])
        plot = int(input('Enter the number assigned to the variable you want to plot: '))
        plt.figure()
        self.data[self.columns[plot]].plot()
        plt.show() 
    
    def list(self):
        print('List of variables read from log file:')
        for i in range(len(self.columns)):
            print('- '+self.columns[i])
