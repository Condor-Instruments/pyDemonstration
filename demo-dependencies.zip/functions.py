# -*- coding: utf-8 -*-

# Sleep-analysis-related functions - 02/2021
# Julius Andretti
# References:

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

def below_prop(a,thresh):
    n = len(a)
    return  np.sum(np.where(a <= thresh,1,0))/n

# Median filter implementation
def median_filter(signal,hws,choice=1,padding=[1,1]):
	# signal is the input data
	# hws is the size of the half-window used
	# choice is an integer used to choose between median and max filtering
	# padding is a list containing padding information

	df = pd.DataFrame(signal)   # Creates a dataframe to use functions from pandas

	if len(padding) == 2:
		pad = pd.DataFrame(padding[0]*np.ones(hws))   # Pads the beggining with a sequence of hws padding[0] values
		df = pd.concat([pad,df],ignore_index=True)
		pad = pd.DataFrame(padding[1]*np.ones(hws))   # Pads the end with a sequence of hws padding[1] values
		df = pd.concat([df,pad],ignore_index=True)

	if choice == 1:
		df = df.rolling(hws*2,center=True).median().iloc[hws:-hws]
	elif choice == 2:
		df = df.rolling(hws*2,center=True).max().iloc[hws:-hws]

	return np.transpose(df.to_numpy())[0]


# Calculates actigraphic scores
def scores(true, predicted, valid_event_on=0.5, valid_event_off=0.5, states=None):
	# true is the desired output
	# predicted is self-explanatory
	# Sequences of event are being analyzed
	# valid_event is the maximal percentage of error needed to classify an event as detected

	true = np.array(true)
	predicted = np.array(predicted)

	ravel = confusion_matrix(true,predicted).ravel()  # Calculates statistical scores
	if len(ravel) > 1:
		tn, fp, fn, tp = ravel
	
		accuracy = (tp+tn)/(tn+fn+fp+tp)
		sensitivity = tp/(tp+fn)
		specificity = tn/(tn+fp)
		precision = tp/(tp+fp)

	else:
		accuracy = 1
		sensitivity = 1
		specificity = 1
		precision = 1

	n = len(true)

	if np.sum(true) == n:
		specificity = 1.0

	elif np.sum(true) == 0:
		sensitivity = 1.0
		precision = 1.0
	
	if states is None:
		# We'll calculate the begginings and endings of sequences of 1s to calculate the error inside them
		edges = np.concatenate([[0], np.diff(true)])

		begin = (edges > 0).nonzero()[0]
		end = (edges < 0).nonzero()[0]

		if true[0] == 1:
			begin = np.insert(begin,0,0)

		if true[-1] == 1:
			end = np.append(end,n)

		over_found = 0
		event_count = len(begin)   # Number of events in true
		valid = 0
		if event_count > 0:
			for i in range(event_count):
				event = predicted[begin[i]:end[i]]

				len_event = end[i]-begin[i]  # Length of event
				error_count = len_event - sum(event)   # Number of erroneous detections

				edges = np.concatenate([[0], np.diff(event)])
				begin_ = (edges < 0).nonzero()[0]
				over_found += len(begin_)

				error = error_count/len_event   # Error percentage

				if error <= valid_event_on:
					valid += 1

			detection = valid/event_count

		else:
			detection = np.nan

		detection_on,valid_on,event_count_on = [detection,valid,event_count]


		begin = (edges < 0).nonzero()[0]
		end = (edges > 0).nonzero()[0]

		if true[0] == 0:
			begin = np.insert(begin,0,0)

		if true[-1] == 0:
			end = np.append(end,n)

		event_count = len(begin)   # Number of events in true
		valid = 0
		if event_count > 0:
			for i in range(event_count):
				if i < len(end):
					len_event = end[i]-begin[i]
					error_count = sum(predicted[begin[i]:end[i]])
				else:
					len_event = n-begin[i]
					error_count = sum(predicted[begin[i]:n])

				error = error_count/len_event   # Error percentage

				if error <= valid_event_off:
					valid += 1

			detection = valid/event_count

		else:
			detection = np.nan

		detection_off,valid_off,event_count_off = [detection,valid,event_count]

		not_found = event_count_off - valid_off

		return [accuracy, sensitivity, specificity, precision, (detection_on,valid_on,event_count_on), (detection_off,valid_off,event_count_off), over_found]

	else:
		# We'll calculate the begginings and endings of sequences of 1s to calculate the error inside them
		edges = np.concatenate([[0], np.diff(true)])

		begin = (edges > 0).nonzero()[0]
		end = (edges < 0).nonzero()[0]

		if true[0] == 1:
			begin = np.insert(begin,0,0)

		if true[-1] == 1:
			end = np.append(end,n)

		over_found = 0
		over_found_sleep = 0
		event_count = len(begin)   # Number of events in true
		valid = 0
		if event_count > 0:
			for i in range(event_count):
				event = predicted[begin[i]:end[i]]

				len_event = end[i]-begin[i]  # Length of event
				error_count = len_event - sum(event)   # Number of erroneous detections

				edges_ = np.concatenate([[0], np.diff(event)])
				begin_ = (edges_ < 0).nonzero()[0]
				end_ = (edges_ > 0).nonzero()[0]
				over_found += len(begin_)

				for b in begin_:
					if states[begin[i] + b] == 1:
						over_found_sleep += 1

				error = error_count/len_event   # Error percentage

				if error <= valid_event_on:
					valid += 1

			detection = valid/event_count

		else:
			detection = np.nan

		detection_on,valid_on,event_count_on = [detection,valid,event_count]

		begin = (edges < 0).nonzero()[0]
		end = (edges > 0).nonzero()[0]

		if true[0] == 0:
			begin = np.insert(begin,0,0)

		if true[-1] == 0:
			end = np.append(end,n)

		event_count = len(begin)   # Number of events in true
		valid = 0
		if event_count > 0:
			for i in range(event_count):
				len_event = end[i]-begin[i]
				error_count = sum(predicted[begin[i]:end[i]])
				error = error_count/len_event   # Error percentage

				if error <= valid_event_off:
					valid += 1

			detection = valid/event_count

		else:
			detection = np.nan

		detection_off,valid_off,event_count_off = [detection,valid,event_count]

		not_found = event_count_off - valid_off

		return [accuracy, sensitivity, specificity, precision, (detection_on,valid_on,event_count_on), (detection_off,valid_off,event_count_off), over_found, over_found_sleep]



# Scales input to be in the [-1,1] interval 
def scale_by_max(signal,scale=None):
	# signal is the input data

	if scale is None:   # Data is divided by its largest value
		factor = 1.0/np.max(np.absolute(signal))
	else:   # Data is the divided by given scalar
		factor = 1.0/scale
	return factor*np.array(np.absolute(signal))


def mean_filter(signal,hws,padding='same'):
    # signal is the input vector
    # hws is the filter half-window length, i.e hws = 1, window_indexes = [center-1,center,center+1]
    
    n = len(signal)
    
    if padding == "same":
        pad = np.zeros(hws)
        filt = np.insert(signal.copy(),0,pad)
        filt = np.append(filt,pad)
        filt = pd.Series(filt).rolling(2*hws+1,center=True).mean().to_numpy()[hws:(n+hws)]

    elif padding == "padded":
        n -= 2*hws
        filt = pd.Series(signal).rolling(2*hws+1,center=True).std().to_numpy()[hws:(n+hws)]

    return filt



# Processes data from read actigraphic log and outputs DataFrame
def log_to_df(log,ws=11,return_all=False):
	# log is the input
	# ws is the size of the window used in variance and covariance computations
	# return_all is a boolean. If true, all calculated variables are returned.

	int_temp = log.temperature
	ext_temp = log.ext_temperature
	offwrist = np.where(log.state == 4, 0, 1)

	datetime = log.timestamps
	df = pd.DataFrame(datetime,columns=["datetime"])

	# All numerical data is scaled beforehand
	act = scale_by_max(log.pim)
	df["pim"] = act 
	df["zcm"] = scale_by_max(log.zcm)

	pad_size = int((ws-1)/2)   # Inputs will be padded before variance is calculated

	df["int_temp"] = scale_by_max(int_temp)
	# pad = df["int_temp"].mean()*np.ones(pad_size)
	# padded = pd.Series(np.concatenate((pad, df["int_temp"].to_numpy(), pad)))   # Padded signal
	# int_var = padded.rolling(ws,center=True).var().to_numpy()[pad_size:(len(padded)-pad_size)]   # Variance is calculated using padded signal

	df["ext_temp"] = (1/max(log.ext_temperature))*np.array(log.ext_temperature)
	# pad = df["ext_temp"].mean()*np.ones(pad_size)
	# padded_aux = pd.Series(np.concatenate((pad, df["ext_temp"].to_numpy(), pad)))
	# ext_var = padded_aux.rolling(ws,center=True).var().to_numpy()[pad_size:(len(padded_aux)-pad_size)]

	# temp_cov = padded.rolling(ws,center=True).cov(padded_aux).to_numpy()[pad_size:(len(padded)-pad_size)]   # Covariance is calculated between both padded signals

	# df["temp_cov"] = scale_by_max(temp_cov)

	# df["int_var"] = scale_by_max(int_var)

	# df["ext_var"] = scale_by_max(ext_var)

	df["dint_temp"] = scale_by_max(np.concatenate(([0],np.diff(int_temp))))
	
	df["dext_temp"] = scale_by_max(np.concatenate(([0],np.diff(ext_temp))))

	df["dif_temp"] = scale_by_max(np.subtract(int_temp,ext_temp))

	diff = np.diff(np.concatenate(([0],int_temp)))
	me_diff = mean_filter(diff,2,padding="same")

	df["diff_temp"] = scale_by_max(np.abs(me_diff))

	df["offwrist"] = offwrist

	if return_all:
		return act, int_temp, ext_temp, int_var, ext_var, temp_cov, offwrist, df

	else:
		return df


# Processes data so that it can be fed to the neural network both for training and testing
def model_data_process(df,ws=20,even=True,cols=['pim','int_temp','ext_temp'],ans="offwrist",use_str=False):
	# df is the input DataFrame
	# ws is the number of timesteps used in each sample
	# If even is True, every sample will be composed of a centering epoch, ws preceding epochs and ws succeeding epochs. 
	# If even is False, every sample will be composed of an epoch and the ws succeeding epochs.
	# cols defines wich columns of the DataFrame will be used in a sample
	# ans is the name of the column containing the desired outcomes. If ans==None, the function only outputs samples.

	n = len(df)    # Number of inputs in the DataFrame
	features = len(cols)   # Number of features
	index_offset = int(df.index[0])
	x = []
	y = []

	if ans is None:
		if even:
			for i in range(index_offset+ws,index_offset+n-ws):
				start = i-ws
				end = i+ws
				if use_str:
					start = str(start)
					end = str(end)
					
				x.append(df.loc[start:end,cols].to_numpy().reshape(2*ws+1,features))

		else:
			for i in range(index_offset,index_offset+n-ws):
				start = i
				end = i+ws
				if use_str:
					start = str(start)
					end = str(end)

				x.append(df.loc[start:end,cols].to_numpy().reshape(ws+1,features))

		return np.array(x)

	else:
		if even:
			for i in range(index_offset+ws,index_offset+n-ws):
				start = i-ws
				end = i+ws
				y_index = i
				if use_str:
					start = str(start)
					end = str(end)
					y_index = str(y_index)

				x.append(df.loc[start:end,cols].to_numpy().reshape(2*ws+1,features))
				y.append(df.at[y_index,ans])

		else:
			for i in range(index_offset,index_offset+n-ws):
				start = i
				end = i+ws
				y_index = i
				if use_str:
					start = str(start)
					end = str(end)
					y_index = str(y_index)

				x.append(df.loc[start:end,cols].to_numpy().reshape(ws+1,features))
				y.append(df.at[y_index,ans])

		return np.array(x),np.array(y)